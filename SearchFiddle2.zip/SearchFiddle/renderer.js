document.addEventListener('DOMContentLoaded', function() {
    const { electron } = window;
    let container = document.querySelector('.components');
    // const ffi = electron.ffi;
    const fs = require('fs');
    //const path = require('path'); // Add path module
    const searchResultsArray = [];
    const searchFor = document.getElementById('searchFor');
    const fileName = document.getElementById('fileName');
    const searchButton = document.getElementById('searchButton');
    const andButton = document.getElementById('andButton');
    const orButton = document.getElementById('orButton');
    const fromDateInput = document.getElementById('fromDate');
    const toDateInput = document.getElementById('toDate');
    const today = new Date();
    const lastWeek = new Date();
    const searchResults = document.getElementById("searchResults");

    // Replace with the actual path to your compiled C++ DLL
    // const myDLL = ffi.Library('C:\Users\bedsp\Documents\GitHub\SearchGUI\dllmain.dll', {
    // 'LoadSearchResults': ['returnType', ['string']],
    // });

    // const cppProcess = spawn(cppDllPath);

    let jsonData = '';

    // Read the JSON data from the C++ process
    // cppProcess.stdout.on('data', (data) => {
    // jsonData += data.toString();
    // });

    // cppProcess.on('close', (code) => {
    // try {
    // const jsonParser = new JsonStreamStringify(jsonData);
    // const parsedData = jsonParser.parse();
    // console.log('Parsed JSON data:', parsedData);
    // } catch (error) {
    // console.error('Error parsing JSON:', error);
    // }
    // });

    // cppProcess.stderr.on('data', (data) => {
    // console.error('C++ error:', data.toString());
    // });

    lastWeek.setDate(today.getDate() - 7); // Subtract 7 days to get last week's date
    flatpickr(fromDateInput, {
        dateFormat: 'm/d/Y',
        defaultDate: lastWeek,
        onChange: function(selectedDates, dateStr, instance) {
            fromDateValue = selectedDates[0]; // Update fromDateValue with the selected date
        }
    });

    flatpickr(toDateInput, {
        dateFormat: 'm/d/Y',
        defaultDate: today,
        onChange: function(selectedDates, dateStr, instance) {
            toDateValue = selectedDates[0]; // Update toDateValue with the selected date
        }
    });

    function isToday(userDate) {
        // Create a Date object for the user-supplied date
        const userDateObj = new Date(userDate);

        // Create a Date object for the current date
        const currentDate = new Date();

        // Compare year, month, and day values
        return (
            userDateObj.getFullYear() === currentDate.getFullYear() &&
            userDateObj.getMonth() === currentDate.getMonth() &&
            userDateObj.getDate() === currentDate.getDate()
        );
    }

    function getDatesBetween(startDate, endDate) {
        const dateArray = [];
        const currentDate = new Date(startDate);
        const targetDate = new Date(endDate);

        while (currentDate <= targetDate) {
            const dateString = currentDate.toLocaleDateString();
            let obj = {
                // linkBut: "fileName1",
                fileDate: dateString
                // fileSize: "Size1",
                // snippet: "Sample from file"
            };

            // if (isToday(currentDate)) {
            // obj.snippet = "This is Today's Date!";
            // }

            dateArray.push(obj);
            currentDate.setDate(currentDate.getDate() + 1);
        }

        return dateArray;
    }

    andButton.addEventListener('click', function() {
        var inputElement = document.getElementById('searchFor');
        var currentValue = inputElement.value;

        if (currentValue.trim() !== '') {
            inputElement.value = currentValue + ';';
        }
    });

    orButton.addEventListener('click', function() {
        var inputElement = document.getElementById('fileName');
        var currentValue = inputElement.value;

        if (currentValue.trim() !== '') {
            inputElement.value = currentValue + ';';
        }
    });

    function searchButtonClick() {
        let num = 1;
        if (!searchButtonClicked) {
            searchButtonClicked = true;
            console.log('Button Clicked');
            searchResultsItems.innerHTML = '';
            // const results = [
            //    { linkBut: "fileName1", fileDate: "Date1", fileSize: "Size1", snippet: "Sample from file" },
            //    { linkBut: "fileName2", fileDate: "Date2", fileSize: "Size2", snippet: "Sample from file" },
            //    { linkBut: "fileName2", fileDate: "Date2", fileSize: "Size2", snippet: "Sample from file" },
            //    { linkBut: "fileName2", fileDate: "Date2", fileSize: "Size2", snippet: "Sample from file" },
            // ... more results
            // ];
            let results; // Change const to let
            const jDates = getDatesBetween(document.getElementById("fromDate").value, document.getElementById("toDate").value);
            // const result = myDLL.LoadSearchResults(param1, param2, ...);
            jDates.forEach(jDateItem => {
                if (isToday(jDateItem)) {
                    results = searchOutput(jDateItem, true, document.getElementById("fileName"));
                } else {
                    results = searchOutput(jDateItem, false, document.getElementById("fileName"));
                }
                results.forEach(resultItem => {
                    const resultDiv = document.createElement("div");
                    resultDiv.className = "searchResults"; // Initially hidden due to CSS class
                    resultDiv.innerHTML = `<div class="linkButton linkButton__primary"><p>${resultItem.linkBut}</p></div><div class="date_size"><div class="date_size__dateResult"><p>${resultItem.fileDate}</p></div><div class="date_size__sizeResult"><p>${resultItem.fileSize}</p></div></div><div class="preview"><p>${resultItem.snippet}</p></div></div>`;
                    searchResultsItems.appendChild(resultDiv);

                    // Adding a small delay before adding the "visible" class to trigger the animation
                    setTimeout(() => {
                        container.classList.add("visible");
                    }, 50 * results.indexOf(resultItem));
                    setTimeout(() => {
                        resultDiv.classList.add("visible");
                    }, 100 * results.indexOf(resultItem));
                });
            });
            setTimeout(() => {
                searchButtonClicked = false;
            }, 10000); // Set a timeout to reset the flag after a certain delay
        }
    }

    let searchButtonClicked = false;
    searchButton.addEventListener('click', searchButtonClick);

    function dateYearToIntSearch(t_Date) {
        const dateYear = parseInt(t_Date.slice(4, 8), 10);
        return dateYear;
    }

    function searchOutput(f_datesFromGUI, f_Today, f_FileName) {
        const fileList = [];
        const filesInDir = [];
        const fileNameMatch = [];
        searchResults.length = 0;

        const todayLoc = 'C:\\Users\\bedsp\\Documents\\R\\';
        const archiveLoc = 'C:\\Users\\bedsp\\Documents\\R\\Archive\\';

        const fileNames = f_FileName.value.split(';');
        for (const fileName of fileNames) {
            fileList.push(`*${fileName}*`);
        }

        if (f_Today) {
            const todayFiles = fs.readdirSync(todayLoc);
            for (const entryFileName of todayFiles) {
                for (const fileName of fileList) {
                    if (wildcardMatch(entryFileName, fileName)) {
                        fileNameMatch.push(entryFileName);
                    }
                }
            }
        }

        filesInDir.length = 0;

        if (fs.existsSync(path.join(archiveLoc, f_datesFromGUI)) && fs.statSync(path.join(archiveLoc, f_datesFromGUI)).isDirectory()) {
            const archiveFiles = fs.readdirSync(path.join(archiveLoc, f_datesFromGUI));
            for (const entryFileName of archiveFiles) {
                for (const fileName of fileList) {
                    if (wildcardMatch(entryFileName, fileName)) {
                        fileNameMatch.push(entryFileName);
                    }
                }
            }
        } else {
            const yearFolder = path.join(archiveLoc, `${dateYearToIntSearch(f_datesFromGUI)}`);
            if (fs.existsSync(yearFolder) && fs.statSync(yearFolder).isDirectory()) {
                const yearFiles = fs.readdirSync(yearFolder);
                if (yearFiles.includes(f_datesFromGUI)) {
                    const dayFolder = path.join(yearFolder, f_datesFromGUI);
                    const dayFiles = fs.readdirSync(dayFolder);
                    for (const entryFileName of dayFiles) {
                        for (const fileName of fileList) {
                            if (wildcardMatch(entryFileName, fileName)) {
                                fileNameMatch.push(entryFileName);
                            }
                        }
                    }
                }
            }
        }

        return fileNameMatch;
    }
});
